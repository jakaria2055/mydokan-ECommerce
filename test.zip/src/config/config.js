export const PORT = 8080;
export const MONGO_URL= process.env.MONGO_URL;