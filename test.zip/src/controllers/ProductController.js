import { BrandListService } from "../services/ProductServices.js"

export const ProductBrandList = async (req, res) =>{
    const result =await BrandListService();
    return res.status(200).json(result);
}