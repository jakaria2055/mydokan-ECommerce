import mongoose from "mongoose";
import BrandModel from "../models/BrandModel.js";
export const BrandListService = async() =>{
    try {
        const data = await BrandModel.find();
        return {status: "success", data: data};
    } catch (e) {
        return {status: "fail", data: e}.toString();
    }
};